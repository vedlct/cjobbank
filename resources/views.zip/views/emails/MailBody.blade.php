<!DOCTYPE html>
<html lang="en">
<body>

Dear {{$employeeInfo['firstName'].' '.$employeeInfo['lastName']}},<br>

Please see the attached file with this email.<br>

Thanks.


<hr>
For any kind of inquiry please contact support@caritasbd.com.





</body>
</html>

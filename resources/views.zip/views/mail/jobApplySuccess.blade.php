<!DOCTYPE html>
<html lang="en">
<body>



<br>
<span>{!! $customBody !!}</span>


<hr>
For any kind of inquiry please contact support@caritasbd.com.





</body>
</html>
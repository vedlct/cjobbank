<!DOCTYPE html>
<html lang="en">
<body>

Dear {{$employeeInfo['firstName'].' '.$employeeInfo['lastName']}},<br>

please see the attached file with this email.<br>

Thanks.




</body>
</html>
@extends('main')

@section('content')

    <div class="row ">

        <div class="col-12 ">
            <div class="card">
                <div style="background-color: #F1F1F1" class="card-body">

                    <form id="regForm" onsubmit="return chkTrainingCertificate()" action="{{route('insert.cvTrainingCertificate')}}" method="post">
                        <!-- One "tab" for each step in the form: -->
                        {{csrf_field()}}

                        <div id="" class="tab">

                            <h2 style="margin-bottom: 30px;text-align: center">Training Certification </h2>

                            <div class="row">
                                <div class="form-group">
                                    <label class="control-label">Has Training Certification?<span style="color: red" class="required">*</span>:</label>
                                    <div class="col-md-10 mb-3">
                                        <input class="form-check-input" type="radio" required <?php if ($hasTrainingInfo=='1'){?>checked<?php } ?> name="hasTrainingInfo" value="1"> Yes&nbsp;&nbsp;
                                    </div>
                                    <div class="col-md-10">
                                        <input class="form-check-input" type="radio" required <?php if ($hasTrainingInfo=='0'){?>checked<?php } ?> name="hasTrainingInfo" value="0"> No&nbsp;&nbsp;
                                    </div>
                                </div>
                            </div>
                            <div style="display: none" id="TrainCertificateDiv">
                            <div id="TextBoxesGroup">

                                <div class="row">
                                    <div class="form-group col-md-12">

                                        <label for="inputEmail4">Name Of The Training<span style="color: red">*</span></label>
                                        <input type="text" class="form-control" name="trainingName[]" id="trainingName" placeholder="training name" >
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-8">
                                        <label for="inputEmail4">Venue <span style="color: red">*</span></label>
                                        <input type="text" class="form-control" name="vanue[]" id="vanue" placeholder="vanue" >
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="inputPassword4">Country<span style="color: red">*</span></label>
                                        {{--<input type="text" class="form-control"  id="inputPassword4" placeholder="">--}}
                                        <select  class="form-control" id="country" name="countryId[]">
                                            <option value="">Select Country</option>
                                            @foreach($countries as $country)
                                                <option value="{{$country->countryId}}">{{$country->countryName}}</option>

                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="inputPassword4">Start Date<span style="color: red">*</span></label>
                                        <input type="text" class="form-control date" name="startDate[]" id="start" placeholder="date" >
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="inputPassword4">End Date</label>
                                        <input type="text" class="form-control date" name="endDate[]" id="end" placeholder="date">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="inputPassword4">Staus<span style="color: red">*</span></label>
                                        <select  class="form-control"id="trainingCertificateStatus" name="status[]">

                                            <option value="">Select Status</option>
                                            @foreach(COMPLETING_STATUS as $key=>$value)
                                                <option value="{{$value}}">{{$key}}</option>
                                            @endforeach
                                        </select>
                                    </div>



                                </div>


                            </div>

                            <button type="button" id="addButton" class="btn btn-success">Add More</button>
                            <button type="button" id="removeButton" class="btn btn-success" >remove</button>

                        </div>
                        </div>

                        <div style="overflow:auto;">
                            <div style="float:right;">
                                <a href="{{route('cv.OthersInfo')}}"><button type="button" id="btnPevious" >Back</button></a>
                                <button type="submit" id="submitBtn">Save</button>
                                @if($hasTrainingInfo == '1' || $hasTrainingInfo == '0')
                                <a href="{{route('candidate.cvProfessionalCertificate')}}"><button type="button" id="btnNext" >Next</button></a>
                                @endif

                            </div>
                        </div>



                        <!-- Circles which indicates the steps of the form: -->
                        <div style="text-align:center;margin-top:40px;">
                            <span class="step"></span>
                            <span class="step"></span>
                            <span class="step"></span>
                            <span class="step"></span>
                            <span class="step"></span>
                            <span class="step"></span>
                            <span class="step"></span>
                        </div>

                    </form>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->

    </div> <!-- end container -->
    </div>
    <!-- end wrapper -->




@endsection

@section('foot-js')
    <script>
        var currentTab = 0; // Current tab is set to be the first tab (0)
        fixStepIndicator(currentTab); // Display the crurrent tab

        function fixStepIndicator(n) {
            // This function removes the "active" class of all steps...
            var x1 = document.getElementsByClassName("tab");
            x1[n].style.display = "block";
            var i, x = document.getElementsByClassName("step");
            for (i = 0; i < x.length; i++) {
                x[i].className = x[i].className.replace(" active", "");
            }
            //... and adds the "active" class on the current step:
            x[(n+3)].className += " active";
        }

        $("input[name=hasTrainingInfo]").click( function () {

            if ($(this).val()=='1'){
                $('#TrainCertificateDiv').show();
            }else {
                $('#TrainCertificateDiv').hide();
            }
        });

        $(document).ready(function(){
            if ('<?php echo $hasTrainingInfo?>'== '0'){

                $('#TrainCertificateDiv').hide();

            }else if ('<?php echo $hasTrainingInfo?>'== '1'){
                $('#TrainCertificateDiv').show();

            }
        });

    </script>





    <script type="text/javascript">
        $(function () {
            $('.date').datepicker({
                format: 'yyyy-m-d'
            });
//            $('#end').datepicker({
//                format: 'yyyy-m-d'
//            });
        });

        function chkTrainingCertificate() {

            if ($("input[name=hasTrainingInfo]:checked").val()=="1") {



                var trainingName = document.getElementsByName('trainingName[]');
                var vanue = document.getElementsByName('vanue[]');
                var country = document.getElementsByName('countryId[]');

                var start = document.getElementsByName('startDate[]');
                var end = document.getElementsByName('endDate[]');
                var trainingCertificateStatus = document.getElementsByName('status[]');

                for (i=0;i<trainingName.length;i++) {


                    if (trainingName[i].value == "") {

                        var errorMsg = 'Please Type a Training Name First!!'
                        validationError(errorMsg)
                        return false;
                    }
                    if (trainingName[i].value.length > 100) {

                        var errorMsg = 'Training Name Should not more than 100 Charecter Length!!'
                        validationError(errorMsg)
                        return false;

                    }
                    if (vanue[i].value == "") {

                        var errorMsg = 'Please Type a Venue First!!'
                        validationError(errorMsg)
                        return false;

                    }
                    if (vanue[i].value.length > 255) {

                        var errorMsg = 'value Should not more than 255 Charecter Length!!';
                        validationError(errorMsg)
                        return false;

                    }
                    if (country[i].value == "") {

                        var errorMsg = 'Please Select a Country First!!';
                        validationError(errorMsg)
                        return false;

                    }

                    if (start[i].value == "") {
                        var errorMsg = 'Please Select a Strat Date First!!';
                        validationError(errorMsg)
                        return false;
                    }
//        if(end==""){
//            var errorMsg='Please Select a End Date First!!';
//            validationError(errorMsg)
//            return false;
//        }

                    if (trainingCertificateStatus[i].value == "") {
                        var errorMsg = 'Please Select a Status First!!';
                        validationError(errorMsg)
                        return false;
                    }

                    if (end[i].value != "") {


                        if (Date.parse(end[i].value) < Date.parse(start[i].value)) {
                            var errorMsg = 'End date should after Start Date!!';
                            validationError(errorMsg);
                            return false;
                        }
                    }
                }
            }else {

                return true;

            }

        }
        $(document).ready(function(){

            var counter = 1;
            $("#removeButton").hide();


            $("#addButton").click(function () {
                if(counter>10){
                    alert("Only 10 Section allow per Time!!");
                    return false;
                }

                if (counter == 1 ){

                    var trainingName=$('#trainingName').val();
                    var vanue=$('#vanue').val();
                    var country=$('#country').val();

                    var start=$('#start').val();
                    var end=$('#end').val();
                    var trainingCertificateStatus=$('#trainingCertificateStatus').val();



                    if(trainingName==""){

                        var errorMsg='Please Type a Training Name First!!'
                        validationError(errorMsg)
                        return false;
                    }
                    if (trainingName.length > 100){

                        var errorMsg='Training Name Should not more than 100 Charecter Length!!'
                        validationError(errorMsg)
                        return false;

                    }
                    if(vanue==""){

                        var errorMsg='Please Type a Venue First!!'
                        validationError(errorMsg)
                        return false;

                    }
                    if (vanue.length > 255){

                        var errorMsg='value Should not more than 255 Charecter Length!!';
                        validationError(errorMsg)
                        return false;

                    }
                    if(country==""){

                        var errorMsg='Please Select a Country First!!';
                        validationError(errorMsg)
                        return false;

                    }

                    if(start==""){
                        var errorMsg='Please Select a Strat Date First!!';
                        validationError(errorMsg)
                        return false;
                    }
                    if(trainingCertificateStatus==""){
                        var errorMsg='Please Select a Status First!!';
                        validationError(errorMsg)
                        return false;
                    }
//                    if(end==""){
//                        var errorMsg='Please Select a End Date First!!';
//                        validationError(errorMsg)
//                        return false;
//                    }

                    if (end != "") {


                        if (Date.parse(end) < Date.parse(start)) {
                            var errorMsg = 'End date should after Start Date!!';
                            validationError(errorMsg);
                            return false;
                        }
                    }



                }
                else {

                    var trainingName=$('#trainingName'+(counter-1)).val();
                    var vanue=$('#vanue'+(counter-1)).val();
                    var country=$('#country'+(counter-1)).val();

                    var start=$('#start'+(counter-1)).val();
                    var end=$('#end'+(counter-1)).val();
                    var trainingCertificateStatus=$('#trainingCertificateStatus'+(counter-1)).val();


                    if(trainingName==""){

                        var errorMsg='Please Type a Training Name First!!'
                        validationError(errorMsg)
                        return false;
                    }
                    if (trainingName.length > 100){

                        var errorMsg='Training Name Should not more than 100 Charecter Length!!'
                        validationError(errorMsg)
                        return false;

                    }
                    if(vanue==""){

                        var errorMsg='Please Type a Venue First!!'
                        validationError(errorMsg)
                        return false;

                    }
                    if (vanue.length > 255){

                        var errorMsg='value Should not more than 255 Charecter Length!!';
                        validationError(errorMsg)
                        return false;

                    }
                    if(country==""){

                        var errorMsg='Please Select a Country First!!';
                        validationError(errorMsg)
                        return false;

                    }
                    if(trainingCertificateStatus==""){
                        var errorMsg='Please Select a Status First!!';
                        validationError(errorMsg)
                        return false;
                    }

                    if(start==""){
                        var errorMsg='Please Select a Strat Date First!!';
                        validationError(errorMsg)
                        return false;
                    }
//                    if(end==""){
//                        var errorMsg='Please Select a End Date First!!';
//                        validationError(errorMsg)
//                        return false;
//                    }

                    if (end != "") {


                        if (Date.parse(end) < Date.parse(start)) {
                            var errorMsg = 'End date should after Start Date!!';
                            validationError(errorMsg);
                            return false;
                        }
                    }


                }




                var newTextBoxDiv = $(document.createElement('div'))
                    .attr("id", 'TextBoxDiv' + counter).attr("class", 'row');
                newTextBoxDiv.after().html(
                    '<div class="col-md-12"><hr style="border-top:1px dotted #000;"></div>'+

                    '<div class="form-group col-md-12"> ' +
                    '<label for="inputEmail4">Name Of The Training<span style="color: red">*</span></label> ' +
                    '<input type="text" class="form-control" name="trainingName[]" id="trainingName'+counter+'" placeholder="training name" required> ' +
                    '</div> ' +

                    '<div class="form-group col-md-8"> ' +
                    '<label for="inputEmail4">Venue <span style="color: red">*</span></label> ' +
                    '<input type="text" class="form-control" name="vanue[]" id="vanue'+counter+'" placeholder="vanue" required> ' +
                    '</div> ' +
                    '<div class="form-group col-md-4"> ' +
                    '<label for="inputPassword4">Country<span style="color: red">*</span></label>' +
                    '<select required class="form-control" id="country'+counter+'" name="countryId[]">'+
                    '<option value="">Select Country</option>'+
                    '@foreach($countries as $country)'+
                    '<option value="{{$country->countryId}}">{{$country->countryName}}</option>'+
                    '@endforeach'+
                    '</select>'+
                    '</div> ' +
                    '<div class="form-group col-md-4"> ' +
                    '<label for="inputPassword4">Start Date<span style="color: red">*</span></label> ' +
                    '<input type="text" class="form-control date" name="startDate[]" id="start'+counter+'" placeholder="date" required> ' +
                    '</div> ' +
                    '<div class="form-group col-md-4"> ' +
                    '<label for="inputPassword4">End Date</label> ' +
                    '<input type="text" class="form-control date" name="endDate[]" id="end'+counter+'" placeholder="date"> ' +
                    '</div>'+
                    '<div class="form-group col-md-4">'+
                    '<label for="inputPassword4">Staus<span style="color: red">*</span></label>'+
                    '<select required class="form-control"id="trainingCertificateStatus" name="status[]">'+

                    '<option value="">Select Status</option>'+
                @foreach(COMPLETING_STATUS as $key=>$value)
                '<option value="{{$value}}">{{$key}}</option>'+
                        @endforeach
                    '</select>'+
                    '</div>'

                );
                newTextBoxDiv.appendTo("#TextBoxesGroup");

                counter++;
                if(counter>1){
//                    document.getElementById("removeButton").style.display='block';
                    $("#removeButton").show();
                }
                $('.date').datepicker({
                    format: 'yyyy-m-d'
                });
            });

            $("#removeButton").click(function () {


                if(counter=='1'){
                    alert("Atleast One Course Section is needed!!");
                    return false;
                }
                counter--;
                if(counter<2){
                    $("#removeButton").hide();
                }
                $("#TextBoxDiv" + counter).remove();
            });


        });

        function validationError(errorMsg){

            $.alert({
                title: 'Error',
                type: 'red',
                content: errorMsg,
                buttons: {
                    tryAgain: {
                        text: 'Ok',
                        btnClass: 'btn-green',
                        action: function () {

                        }
                    }
                }
            });

        }

    </script>



@endsection
